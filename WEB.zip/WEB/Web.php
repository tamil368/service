<?php
// Include the database configuration file
require_once './php/db.php';

// Check if $db is set and not null
if (!isset($db) || $db === null) {
    die("Database connection is not established.");
}

// Execute the query to retrieve data from the database
$result = $db->query("SELECT * FROM images ORDER BY id DESC");

// Proceed with further operations based on $result
?>

<!Doctype html>
<html lang="en">
  <head>
    <title>SID &mdash; </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="keywords" content="html, css, javascript, jquery">
    <meta name="author" content="">
    <link rel="stylesheet" href="css/vendor/icomoon/style.css">
    <link rel="stylesheet" href="css/vendor/owl.carousel.min.css">
    <link rel="stylesheet" href="css/vendor/animate.min.css">
    <link rel="stylesheet" href="css/vendor/aos.css">
    <link rel="stylesheet" href="css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="css/vendor/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/style.css">
 </head>
<body data-spy="scroll" data-target=".site-nav-target" data-offset="200">
    <nav class="unslate_co--site-mobile-menu">
      <div class="close-wrap d-flex">
        <a href="#" class="d-flex ml-auto js-menu-toggle">
          <span class="close-label">Close</span>
          <div class="close-times">
            <span class="bar1"></span>
            <span class="bar2"></span>
          </div>
        </a>
      </div>
      <div class="site-mobile-inner"></div>
    </nav>
    <div class="unslate_co--site-wrap">
      <div class="unslate_co--site-inner">
        <div class="lines-wrap">
          <div class="lines-inner">
           
          </div>
        </div>
        <!-- END lines -->     
      <nav class="unslate_co--site-nav site-nav-target">
        <div class="container">        
          <div class="row align-items-center justify-content-between text-left">
            <div class="col-md-5 text-right">
              <ul class="site-nav-ul js-clone-nav text-left d-none d-lg-inline-block">
                <li class="has-children">
                  <a href="#home-section" class="nav-link">Home</a>
                  
                </li>
                <li><a href="#portfolio-section" class="nav-link">Events</a></li>
                <li><a href="#about-section" class="nav-link">CEO</a></li>
                <li><a href="#services-section" class="nav-link">Services</a></li>
              </ul>
            </div>
            <div class="site-logo pos-absolute">
              <a  href="#" class="unslate_co--site-logo">SID<span></span></a>
            </div>
            <div class="col-md-5 text-right text-lg-left">
              <ul class="site-nav-ul js-clone-nav text-left d-none d-lg-inline-block">
                <li><a href="#skills-section" class="nav-link">Skills</a></li>
                <li><a href="#testimonial-section" class="nav-link">Team Members</a></li>
                <li><a href="#contact-section" class="nav-link">Contact</a></li>
                <li><a href="admin.html" class="nav-link">Admin Login</a></li>
              </ul>
              
              <ul class="site-nav-ul-none-onepage text-right d-inline-block d-lg-none">
                <li><a href="#" class="js-menu-toggle">Menu</a></li>
              </ul>

            </div>
          </div>
        </div>

      </nav>
      <!-- END nav -->

      <div class="cover-v1 jarallax" style="background-image: url('images/abg1.jpeg');" id="home-section">
        <div class="container">
          <div class="row align-items-center">
              
            <div class="col-md-7 mx-auto text-center">
              <h1 class="gsap-reveal-hero" style="color: rgb(6, 166, 240); font-weight: bold;">SID's Cyber Solutions</h1>


              <h2 class="subheading gsap-reveal-hero" style="color: rgb(57, 133, 168);">Ethical Hacking</h2>
             
            </div>

          </div>
        </div>


        <a href="#portfolio-section" class="mouse-wrap smoothscroll">
          <span class="mouse">
            <span class="scroll"></span>
          </span>
          <span class="mouse-label">Scroll</span>
        </a>

      </div>
      <!-- END .cover-v1 -->
      <div class="unslate_co--section" id="portfolio-section">
        <div class="container">
        <?php if ($result->num_rows > 0) { ?>
    <div class="portfolio-wrapper">
        <div class="d-flex align-items-center mb-4 gsap-reveal gsap-reveal-filter">
            <h2 class="mr-auto heading-h2"><span class="gsap-reveal">Events</span></h2>
        </div>
        <div class="row gutter-isotope-item">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="portfolio-item">
                        <img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" class="img-fluid" alt="Image">
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
<?php } else { ?>
    <p class="status error">Image(s) not found...</p>
<?php } ?>
        </div>
    </div>
     

      <div class="unslate_co--section" id="about-section">
        <div class="container">
          
          <div class="section-heading-wrap text-center mb-5">
            <h2 class="heading-h2 text-center divider"><span class="gsap-reveal">About SID</span></h2>
            <span class="gsap-reveal"><img src="images/divider.png" alt="divider" width="76"></span>
            <span class="gsap-reveal">
            
            </span>
          </div>
          

          <div class="row mt-5 justify-content-between">
            <div class="col-lg-7 mb-5 mb-lg-0">
              
                <img src="images/aboutme.jpg" alt="Image" class="img-fluid">
                
              </figure>
            
            </div>
            <div class="col-lg-4 pr-lg-5">
              <h3 class="mb-4 heading-h3"><span class="gsap-reveal">Ethical Hacker</span></h3>
              <p class="lead gsap-reveal">Cyber Warrior <a href="#"> Let's Hack It !</a>  </p>
              <p class="lead gsap-reveal">Nothing is IM<a href="#">POSSIBLE!</a>  </p>
              
            </div>
          </div>
        </div>
      </div>

      <div class="unslate_co--section" id="services-section">
        <div class="container">

          <div class="section-heading-wrap text-center mb-5">
            <h2 class="heading-h2 text-center divider"><span class="gsap-reveal">My Services</span></h2>
            <span class="gsap-reveal"><img src="images/divider.png" alt="divider" width="76"></span>
          </div>

          <div class="row gutter-v3">
            <div class="col-md-6 col-lg-4 mb-4">
              <div class="feature-v1" data-aos="fade-up" data-aos-delay="0">
                <div class="wrap-icon mb-3">
                  <img src="images/s1.png" alt="Image"height="80" width="80">
                </div>
                <h3>Ethical  <br> Hacking</h3>
                <p>We Provides System Hacking Ethically for Multi National Companies When System Security is Hacked. </p>
              </div> 
            </div>
            <div class="col-md-6 col-lg-4 mb-4">
              <div class="feature-v1" data-aos="fade-up" data-aos-delay="100">
                <div class="wrap-icon mb-3">
                  <img src="images/s4.png" alt="Image"height="60" width="110">
                </div>
                <h3> Ethical <br> Challenges</h3>
                <p>We Accept Security Checking Challenges by Cracking your Website and Reworking on it to Make a Better Website for You. </p>
              </div> 
            </div>
            <div class="col-md-6 col-lg-4 mb-4">
              <div class="feature-v1" data-aos="fade-up" data-aos-delay="200">
                <div class="wrap-icon mb-3">
                  <img src="images/s5.png" alt="Image"height="60" width="60">
                </div>
                <h3>User <br> Experience</h3>
                <p>Users Will Experience a Smooth and Safe feel With Our Softwares </p>
              </div> 
            </div>

            <div class="col-md-6 col-lg-4 mb-4">
              <div class="feature-v1" data-aos="fade-up" data-aos-delay="0">
                <div class="wrap-icon mb-3">
                  <img src="images/s3.png" alt="Image"height="120" width="180">
                </div>
                <h3>Cyber <br> Warriors</h3>
                <p>As a member of the Charter of Trust and with our own Cyber Emergency Response Team, we proactively guarantee the most up-to-date protection for our customers and our own factories. When necessary, Security Advisories also inform you of current threats to your company and any necessary updates to our products. </p>
              </div> 
            </div>
            <div class="col-md-6 col-lg-4 mb-4">
              <div class="feature-v1" data-aos="fade-up" data-aos-delay="100">
                <div class="wrap-icon mb-3">
                  <img src="images/s6.png" alt="Image"height="120" width="180">
                </div>
                <h3>Cyber<br> Seminars</h3>
                <p> We Provide Cyber Seminars for Students and Workers for Awareness and Learning Purposes. </p>
              </div> 
            </div>
            <div class="col-md-6 col-lg-4 mb-4">
              <div class="feature-v1" data-aos="fade-up" data-aos-delay="200">
                <div class="wrap-icon mb-3">
                  <img src="images/s2.jpg" alt="Image"height="120" width="180">
                </div>
                <h3>Multilayer Defense-in-Depth<br> concept </h3>
                <p>Protecting individual areas is no longer sufficient for withstanding the various threats. Our Defense-in-Depth concept is strengthened by Zero Trust principles and is supported by three pillars: plant security, network security, and system integrity.</p>
              </div> 
            </div>

          </div>
        </div>
      </div>

      <div class="unslate_co--section section-counter" id="skills-section">
        <div class="container">
          <div class="section-heading-wrap text-center mb-5">
            <h2 class="heading-h2 text-center divider"><span class="gsap-reveal">Our Skills</span></h2>
            <span class="gsap-reveal"><img src="images/divider.png" alt="divider" width="76"></span>
          </div>


          <div class="row pt-5">
            <div class="col-6 col-sm-6 mb-5 mb-lg-0 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="0">
              <div class="counter-v1 text-center">
                <span class="number-wrap">
                  <span class="number number-counter" data-number="90">0</span>
                  <span class="append-text">%</span>
                </span>
                <span class="counter-label">Cracking Tech</span>
              </div>
            </div>
            <div class="col-6 col-sm-6 mb-5 mb-lg-0 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
              <div class="counter-v1 text-center">
                <span class="number-wrap">
                  <span class="number number-counter" data-number="99">0</span>
                  <span class="append-text">%</span>
                </span>
                <span class="counter-label">BlockChain</span>
              </div>
            </div>
            <div class="col-6 col-sm-6 mb-5 mb-lg-0 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
              <div class="counter-v1 text-center">
                <span class="number-wrap">
                  <span class="number number-counter" data-number="95">0</span>
                  <span class="append-text">%</span>
                </span>
                <span class="counter-label">Cyber forensics</span>
              </div>
            </div>
            <div class="col-6 col-sm-6 mb-5 mb-lg-0 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
              <div class="counter-v1 text-center">
                <span class="number-wrap">
                  <span class="number number-counter" data-number="100">0</span>
                  <span class="append-text">%</span>
                </span>
                <span class="counter-label">web security</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- END .counter -->

      <div class="unslate_co--section" id="testimonial-section">
    <div class="container">
        <div class="section-heading-wrap text-center mb-5">
            <h2 class="heading-h2 text-center divider"><span class="gsap-reveal">Sid's Team Members</span></h2>
            <span class="gsap-reveal"><img src="images/divider.png" alt="divider" width="76"></span>
        </div>
    </div>

    <div class="owl-carousel testimonial-slider" data-aos="fade-up">
        <div class="testimonial-v1">
            <?php
            // Database configuration
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "siddarth";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Retrieve image data along with name and specification from database
            $imageResult = $conn->query("SELECT name, specification, image FROM user_data ORDER BY id DESC");

            if ($imageResult->num_rows > 0) { ?>
                <div class="gallery">
                    <?php while ($row = $imageResult->fetch_assoc()) { ?>
                        <div>
                            <p>Name: <?php echo $row['name']; ?></p>
                            <p>Specification: <?php echo $row['specification']; ?></p>
                            <img src="data:image/jpg;base64,<?php echo base64_encode($row['image']); ?>" />
                        </div>
                    <?php } ?>
                </div>
            <?php } else { ?>
                <p class="status error">Data not found...</p>
            <?php } ?>

            <?php $conn->close(); ?>
        </div>
    </div>
</div>

  


      <div class="unslate_co--section" id="contact-section">
        <div class="container">
          <div class="section-heading-wrap text-center mb-5">
            <h2 class="heading-h2 text-center divider"><span class="gsap-reveal">Get In Touch</span></h2>
            <span class="gsap-reveal"><img src="images/divider.png" alt="divider" width="76"></span>
          </div>


          <div class="row justify-content-between">
            
            <div class="col-md-6">
              <form method="post" class="form-outline-style-v1" id="contactForm" action="./send-email.php">
                <div class="form-group row mb-0">
                    <div class="col-lg-6 form-group gsap-reveal">
                        <label for="name">Name</label>
                        <input name="name" type="text" class="form-control" id="name">
                    </div>
                    <div class="col-lg-6 form-group gsap-reveal">
                        <label for="email">Email</label>
                        <input name="email" type="email" class="form-control" id="email">
                    </div>
                    <div class="col-lg-12 form-group gsap-reveal">
                        <label for="message">Write your message...</label>
                        <textarea name="message" id="message" cols="30" rows="7" class="form-control"></textarea>
                    </div>
                </div>
                <div class="form-group row gsap-reveal">
                    <div class="col-md-12 d-flex align-items-center">
                        <input type="submit" class="btn btn-outline-pill btn-custom-light mr-3" value="Send Message">
                        <span class="submitting"></span>
                    </div>
                </div>
            </form>
            
              <div id="form-message-warning" class="mt-4"></div> 
              <div id="form-message-success">
                Your message was sent, thank you!
              </div>

            </div>

            <div class="col-md-4">
              <div class="contact-info-v1">
                <div class="gsap-reveal d-block">
                  <span class="d-block contact-info-label">Email</span>
                  <a href="#" class="contact-info-val">siddharththirumalairaj@gmail.com</a>
                </div>
                <div class="gsap-reveal d-block">
                  <span class="d-block contact-info-label">Phone</span>
                  <a href="#" class="contact-info-val">+91 9876543210</a>
                </div>
                <div class="gsap-reveal d-block">
                  <span class="d-block contact-info-label">Address</span>
                  <address class="contact-info-val">Thanjavur <br> TamilNadu</address>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      </div> 

      <footer class="unslate_co--footer unslate_co--section">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-7">
              
              <div class="footer-site-logo"><a href="#">SID<span></span></a></div>

              <ul class="footer-site-social">
                <li><a href="#">Whatsapp</a></li>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Instagram</a></li>
                <li><a href="#">Twitter</a></li>
                
              </ul>

              <p class="site-copyright">
                
               
                Copyright &copy;
                <script>
                  document.write(new Date().getFullYear());
                </script> All Rights Resereved with SID <i class="icon-heart"
                  aria-hidden="true"></i> 
              
              
              </p>

            </div>
          </div>
        </div>
      </footer>

      
    </div>

    
    
    <div id="unslate_co--overlayer"></div>
    <div class="site-loader-wrap">
      <div class="site-loader"></div>
    </div>

    <script src="js/scripts-dist.js"></script>
    <script src="js/main.js"></script>

  </body>
</html>