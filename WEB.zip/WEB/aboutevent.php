<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <style>
        /* Basic styling for the form */
form {
    width: 300px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* Style for the label */
label {
    display: block;
    margin-bottom: 10px;
}

/* Style for the file input */
input[type="file"] {
    display: block;
    margin-bottom: 10px;
}

/* Style for the submit button */
input[type="submit"] {
    display: block;
    width: 100%;
    padding: 10px;
    background-color: #007bff; /* Default button color */
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease; /* Smooth transition */
}

/* Hover effect for the submit button */
input[type="submit"]:hover {
    background-color: #28a745; /* Change button color on hover */
}

/* Additional hover effect with different color */
input[type="submit"]:hover {
    background-color: #dc3545; /* Change button color on hover */
}

    </style>
</head>
<body>
<div class="wrapper">
    <?php if (!empty($statusMsg)) { ?>
        <p class="status <?php echo $status; ?>">
            <?php echo $statusMsg; ?>
        </p>
    <?php } ?>


    <form action="./php/images.php" method="post" enctype="multipart/form-data">
        <label>Select Image File:</label>
        <input type="file" name="image">
        <input type="submit" name="submit" value="Upload">
    </form>
</div>
    <script>
    
    </script>
</body>
</html>
