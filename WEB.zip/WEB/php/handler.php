<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "siddarth";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If file upload form is submitted
$status = $statusMsg = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $specification = $_POST['specification'];

    // Check if image file is selected
    if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {
        $fileName = basename($_FILES["image"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
        if (in_array($fileType, $allowTypes)) {
            // Reconnect to the database
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $image = $_FILES['image']['tmp_name'];
            $imgContent = addslashes(file_get_contents($image));

            // Assign $imagePath before using it in SQL query
            $imagePath = "uploads/$fileName";

            try {
                // Check if data already exists
                $checkSql = "SELECT * FROM user_data WHERE name='$name' AND specification='$specification'";
                $result = $conn->query($checkSql);
                if ($result->num_rows > 0) {
                    $statusMsg = "Data already exists";
                } else {
                    // Insert data into database
                    $sql = "INSERT INTO user_data (name, specification, image, created) VALUES ('$name', '$specification', '$imagePath', NOW())";
                    if ($conn->query($sql) === TRUE) {
                        $status = 'success';
                        $statusMsg = "File uploaded and data inserted successfully.";
                    } else {
                        $statusMsg = "Error inserting data: " . $conn->error;
                    }
                }
            } catch (mysqli_sql_exception $e) {
                $statusMsg = "Error: " . $e->getMessage();
            }
        } else {
            $statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        }
    } else {
        $statusMsg = 'Please select an image file to upload.';
    }
}

// Retrieve image data along with name and specification from database
// Display status message
echo $statusMsg;

// Close connection
$conn->close();
?>
