<?php 
 include './db.php';
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $specification = $_POST['specification'];
    
    // Check if image file is selected
    if(isset($_FILES['image'])){
        $file_name = $_FILES['image']['name'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // Move uploaded file to directory
        $randomDir = uniqid();
        mkdir("uploads/$randomDir"); // Create a random directory
        move_uploaded_file($file_tmp, "uploads/$randomDir/$file_name");

        // Insert data into database
        $sql = "INSERT INTO user_data (name, specification, image) VALUES ('$name', '$specification', 'uploads/$randomDir/$file_name')";
        if ($conn->query($sql) === TRUE) {
            echo "Data stored successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();

?>