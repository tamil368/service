<?php 
include './php/conn.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>papers</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            height: 2000px; /* Adjust the height as needed */
        }

        .parallax {
            /* The image used */
            background-image: url('your-background-image.jpg');

            /* Full height */
            height: 100%;

            /* Create the parallax scrolling effect */
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .card-body {
            padding: 80px 20px; /* Add padding to avoid content overlaying with background */
        }

        /* Style the table */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #f2f2f2;
        }

        /* Style links */
        .link {
            text-decoration: none;
            color: blue;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="parallax">
    <!-- Content with parallax background -->
    <div class="card-body">
        <div class="table-responsive">
            <table>
                <thead>
                    <th>ID</th>
                    <th>UserName</th>
                    <th>EMAIL</th>
                    <th>PAPERS</th>
                    <th>Actions</th> <!-- Added Actions column -->
                </thead>
                <tbody>
                    <?php
                        // Check if $conn is set and not null
                        if ($conn) {
                            $selectQuery = "SELECT * FROM paperdetail";
                            $squery = mysqli_query($conn, $selectQuery);

                            if ($squery) {
                                while ($result = mysqli_fetch_assoc($squery)) {
                    ?>
                    <tr>
                        <td><?php echo $result['id']; ?></td>
                        <td><?php echo $result['username']; ?></td>
                        <td><?php echo $result['email']; ?></td>
                        <td><?php echo $result['file_path']; ?></td>
                        <td>
                        <a href="./view.php?php echo $result['file_path']; ?>" target="_blank" class="link">View</a>
 <!-- Link to view file -->
                            |
                            <a href="edit.php?id=<?php echo $result['id']; ?>" class="link">Edit</a> <!-- Link to edit file -->
                        </td>
                    </tr>
                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='5'>Error: " . mysqli_error($conn) . "</td></tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>Connection error: Unable to connect to the database</td></tr>";
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Other content goes here -->

</body>
</html>
