<?php
include './php/conn.php';
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = isset($_POST['input-username']) ? $_POST['input-username'] : null;
    $email = isset($_POST['input-email']) ? $_POST['input-email'] : null;
    $first_name = isset($_POST['input-first-name']) ? $_POST['input-first-name'] : null;
    $last_name = isset($_POST['input-last-name']) ? $_POST['input-last-name'] : null;
    $address = isset($_POST['input-address']) ? $_POST['input-address'] : null;
    $city = isset($_POST['input-city']) ? $_POST['input-city'] : null;
    $country = isset($_POST['input-country']) ? $_POST['input-country'] : null;
    $file_path = isset($_FILES['file']['name']) ? $_FILES['file']['name'] : null;
    $file_tmp = isset($_FILES['file']['tmp_name']) ? $_FILES['file']['tmp_name'] : null;
    
    // Check if any required fields are empty
    if (empty($username) || empty($email) || empty($first_name) || empty($last_name) || empty($address) || empty($city) || empty($country) || empty($file_path)) {
        die("<script>alert('All fields are required');</script>");
    }

    // Database configuration
    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "singup";

    // Create connection
    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind the SQL statement
    $sql = "INSERT INTO paperdetail (username, email, first_name, last_name, address, city, country, file_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $username, $email, $first_name, $last_name, $address, $city, $country, $file_path);

    // Execute the statement
    if ($stmt->execute()) {
        // Move uploaded file to desired directory
      
      
        if (move_uploaded_file($file_tmp, $file_path)) {
            echo "<script>alert('New record created successfully');</script>";
        } else {
            echo "<script>alert('Failed to move uploaded file');</script>";
        }
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>upload</title>
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://demos.creative-tim.com/soft-ui-dashboard/assets/css/nucleo-icons.css">
    <link rel="stylesheet" href="https://demos.creative-tim.com/soft-ui-dashboard/assets/css/nucleo-svg.css">
    <link rel="stylesheet" href="https://demos.creative-tim.com/soft-ui-dashboard/assets/css/soft-ui-dashboard.min.css?v=1.0.2">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
    <link rel="stylesheet" href="./assets/css/theme.css">
    <link rel="stylesheet" href="./assets/css/loopple/loopple.css">
    <style></style>
</head>

<body class="g-sidenav-show">
    <div class="container-fluid pt-3">
        <center> <h1> Create Conference</h1></center>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <h6 class="heading-small text-muted mb-4">User information</h6>
                <div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-username">Username</label>
                                <input type="text" id="input-username" name="input-username" class="form-control" placeholder="Username" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-email">Email address</label>
                                <input type="email" id="input-email" name="input-email" class="form-control" placeholder="Email" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-first-name">First name</label>
                                <input type="text" id="input-first-name" name="input-first-name" class="form-control" placeholder="First name" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-last-name">Last name</label>
                                <input type="text" id="input-last-name" name="input-last-name" class="form-control" placeholder="Last name" required>
                            </div>
                        </div>
                    </div>
                </div>
                <hr class="horizontal dark my-4">
                <!-- Address -->
                <h6 class="heading-small text-muted mb-4">Author information</h6>
                <div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-control-label" for="input-address">Address</label>
                                <input id="input-address" name="input-address" class="form-control" placeholder="Home Address"  type="text" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label" for="input-city">City</label>
                                <input type="text" id="input-city" name="input-city" class="form-control" placeholder="City" required>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label" for="input-country">Country</label>
                                <input type="text" id="input-country" name="input-country" class="form-control" placeholder="Country"  required>
                            </div>
                        </div>
                    </div>
                </div>
                <hr class="horizontal dark my-4">
                <!-- Description -->
                <h6 class="heading-small text-muted mb-4">Upload</h6>
                <div class="form-group">
                    <label class="form-control-label">Upload file</label>
                    <input type="file" id="file" name="file" class="form-control" placeholder="Upload papers" required>
                </div>
                <div class="form-group row">
                    <div class="col-lg-12">
                        <input type="submit" class="btn btn-primary btn-lg" value="Submit">  
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
