<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST['c_uname'];
    $password = $_POST['c_password'];

    // Database configuration
    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "singup"; // Replace 'your_database_name' with your actual database name

    // Create connection
    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind the SQL statement
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);

    // Execute the statement
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if user exists in the database
    if ($result->num_rows > 0) {
        // User exists, fetch user data
        $row = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $row['password'])) {
            // Password is correct, redirect to meeting.php
            header("Location: meeting.php");
            exit();
        } else {
            // Password is incorrect
            echo "<script>alert('Incorrect password.');</script>";
        }
    } else {
        // User does not exist
        echo "<script>alert('User does not exist.');</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>welcome &mdash; conference management system</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900"> 
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/style.css">

</head>
<body>
  <div class="col-md-5 mb-5">
    <h3 class="mb-5">Login</h3>
    <form action="#" method="post" class="bg-white">
      
      <div class="">
        <div class="form-group row">
          <div class="col-md-12">
            <label for="c_uname" class="text-black">Username <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="c_fname" name="c_uname">
          </div>
        </div>
        <div class="form-group row">
          <div class="col-md-12">
            <label for="c_password" class="text-black">Password <span class="text-danger">*</span></label>
            <input type="password" class="form-control" id="c_pass" name="c_password">
          </div>
        </div>
        
        <div class="form-group row">
          <div class="col-lg-12">
            <input type="submit" class="btn btn-primary btn-lg" value="Login">
          </div>
        </div>
      </div>
    </form>
  </div>
  

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/mediaelement-and-player.min.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var mediaElements = document.querySelectorAll('video, audio'), total = mediaElements.length;

      for (var i = 0; i < total; i++) {
        new MediaElementPlayer(mediaElements[i], {
          pluginPath: 'https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/',
          shimScriptAccess: 'always',
          success: function () {
            var target = document.body.querySelectorAll('.player'), targetTotal = target.length;
            for (var j = 0; j < targetTotal; j++) {
              target[j].style.visibility = 'visible';
            }
          }
        });
      }
    });
  </script>


  <script src="js/main.js"></script>

</body>
</html>