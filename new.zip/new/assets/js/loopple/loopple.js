// document.querySelector('.loopple-alert.loopple-alert-dismissible .close').onclick=function(){document.querySelector('.loopple-alert').classList.add('loopple-opacity-0');setTimeout(function(){document.querySelector('.loopple-alert').remove();},1000);}
// // Add a click event listener to the logout button
// document.getElementById('btn').addEventListener('click', function() {
//     // Perform logout functionality here (e.g., clearing session storage, etc.)
    
//     // Redirect to index.html
//     window.location.href = 'index.html';
// });
// document.querySelector('.loopple-alert.loopple-alert-dismissible .close').onclick=function(){document.querySelector('.loopple-alert').classList.add('loopple-opacity-0');setTimeout(function(){document.querySelector('.loopple-alert').remove();},1000);}