<?php
// Define database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "siddarth";

// Establish database connection
$db = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($db->connect_error) {
    die("Database connection failed: " . $db->connect_error);
}
?>
