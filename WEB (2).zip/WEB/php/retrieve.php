<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "siddarth";

// Establish database connection
$db = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($db->connect_error) {
    die("Database connection failed: " . $db->connect_error);
}

// Query to fetch records from user_data table
$sql = "SELECT * FROM user_data";
$result = $db->query($sql);

// Check if there are any records
if ($result && $result->num_rows > 0) {
    ?>
    <div class="section-heading-wrap text-center mb-5">
        <h2 class="heading-h2 text-center divider"><span class="gsap-reveal">Sid's Team Members</span></h2>
        <span class="gsap-reveal"><img src="images/divider.png" alt="divider" width="76"></span>
    </div>

    <div class="owl-carousel testimonial-slider" data-aos="fade-up">
        <?php
        // Loop through each row in the result set
        while ($row = $result->fetch_assoc()) {
            ?>
            <div class="testimonial-v1">
                <h3><?php echo $row['name']; ?></h3>
                <p><?php echo $row['specification']; ?></p>
                <img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" width="200px" height="400px" /> 
            </div>
            <?php
        }
        ?>
    </div>
    <?php
} else {
    ?>
    <p class="status error">No team members found...</p>
    <?php
}

// Close the database connection
$db->close();
?>
