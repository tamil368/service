<?php
include './db.php'; 

// Initialize $statusMsg variable
$statusMsg = '';

// If form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $specification = $_POST['specification'];

    if (!empty($_FILES["image"]["name"])) {
        // Get file info
        $fileName = basename($_FILES["image"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        // Allow certain file formats
        $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
        if (in_array($fileType, $allowTypes)) {
            // Reconnect to the database
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $image = $_FILES['image']['tmp_name'];
            $imgContent = addslashes(file_get_contents($image));

            // Insert data into database
            $sql = "INSERT INTO user_data (name, specification, image, created) VALUES ('$name', '$specification', '$imgContent', NOW())";
            if ($db->query($sql) === TRUE) {
                echo "Record inserted successfully.";
            } else {
                echo "Error inserting record: " . $db->error;
            }
        } else {
            $statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        }
    } else {
        $statusMsg = 'Please select an image file to upload.';
    }

    // Display status message if any
    if (!empty($statusMsg)) {
        echo $statusMsg;
    }
} else {
    // Redirect to form page if accessed directly
    header("Location: web.php");
    exit;
}
?>
